<div style="clear:both"> </div>
</div><?php //closing for #main ?>
<div id="footer">
  <?php // It's completely optional, but if you like the theme I would appreciate it if you keep the credit link at the bottom. ?>
	<p>
		<span>
		<a href="http://wp-templates.ru/">WordPress шаблоны</a>
		</span>
		Все права защищены &copy; <?php echo date('Y'); ?> <a href="/"><strong><?php bloginfo('name'); ?></strong></a>. <?php bloginfo('description'); ?>
	</p>
</div>
<?php wp_footer();?>
</body>
</html>